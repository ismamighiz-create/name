package com.perso.flix

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private val Accent = Color(0xFFE50914)
private val Panel = Color(0xE619191F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("flix", MODE_PRIVATE)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Color(0xFF09090B))) {
                Surface(Modifier.fillMaxSize(), color = Color(0xFF09090B)) { App(prefs) }
            }
        }
    }
}

data class Ep(val uri: Uri, val name: String)

fun scan(ctx: Context, tree: Uri): List<Ep> {
    val root = DocumentFile.fromTreeUri(ctx, tree) ?: return emptyList()
    val out = mutableListOf<Ep>()
    fun walk(d: DocumentFile) {
        for (f in d.listFiles()) {
            val n = f.name ?: continue
            if (f.isDirectory) walk(f)
            else if (n.substringAfterLast('.', "").lowercase() in setOf(
                    "mp4", "m4v", "mkv", "webm", "avi", "mov", "3gp",
                    "ts", "m2ts", "mpg", "mpeg", "ogv", "flv"
                )) out += Ep(f.uri, n.substringBeforeLast('.'))
        }
    }
    walk(root)
    // Tri naturel : Série 2 avant Série 10, même avec des numéros à plusieurs chiffres.
    return out.sortedBy { e ->
        e.name.lowercase().replace(Regex("\\d+")) { it.value.padStart(12, '0') }
    }
}

fun SharedPreferences.pos(e: Ep) = getLong("p_${e.uri}", 0L)
fun SharedPreferences.dur(e: Ep) = getLong("d_${e.uri}", 0L)
fun SharedPreferences.progress(e: Ep): Float {
    val d = dur(e); return if (d > 0) (pos(e).toFloat() / d).coerceIn(0f, 1f) else 0f
}

@Composable
fun App(prefs: SharedPreferences) {
    val ctx = LocalContext.current
    var tree by remember { mutableStateOf(prefs.getString("tree", null)) }
    var eps by remember { mutableStateOf(listOf<Ep>()) }
    var current by remember { mutableStateOf<Int?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            prefs.edit().putString("tree", uri.toString()).apply()
            tree = uri.toString()
        }
    }
    LaunchedEffect(tree) {
        eps = tree?.let { t -> withContext(Dispatchers.IO) { scan(ctx, Uri.parse(t)) } } ?: emptyList()
    }
    BackHandler(current != null) { current = null }
    val c = current
    if (c != null) Playback(eps, c, prefs) { current = null }
    else Library(eps, prefs, onPick = { picker.launch(null) }, onPlay = { current = it })
}

@Composable
fun Library(eps: List<Ep>, prefs: SharedPreferences, onPick: () -> Unit, onPlay: (Int) -> Unit) {
    if (eps.isEmpty()) {
        Column(Modifier.fillMaxSize().background(Color(0xFF09090B)), Arrangement.Center, Alignment.CenterHorizontally) {
            Text("MA SÉRIE", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(8.dp))
            Text("Aucune vidéo trouvée", color = Color.LightGray)
            Spacer(Modifier.height(18.dp))
            Button(onClick = onPick, colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                Text("Choisir le dossier de la série")
            }
        }
        return
    }
    val resume = eps.indices.filter { prefs.progress(eps[it]) in 0.01f..0.95f }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(160.dp),
        modifier = Modifier.fillMaxSize().background(Color(0xFF09090B)),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Column {
                    Text("MA SÉRIE", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                    Text("${eps.size} épisodes", color = Color.Gray, fontSize = 13.sp)
                }
                TextButton(onClick = onPick) { Text("Changer de dossier", color = Color.White) }
            }
        }
        if (resume.isNotEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text("Continuer à regarder", color = Color.White, style = MaterialTheme.typography.titleMedium)
            }
            items(resume) { i -> Card(eps[i], prefs) { onPlay(i) } }
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text("Tous les épisodes", color = Color.White, style = MaterialTheme.typography.titleMedium)
            }
        }
        items(eps.indices.toList()) { i -> Card(eps[i], prefs) { onPlay(i) } }
    }
}

@Composable
fun Card(e: Ep, prefs: SharedPreferences, onClick: () -> Unit) {
    val p = prefs.progress(e)
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF202027)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f)) {
            Text(e.name, Modifier.align(Alignment.Center).padding(12.dp), maxLines = 3,
                overflow = TextOverflow.Ellipsis, color = Color.White, fontWeight = FontWeight.SemiBold)
            if (p > 0f) LinearProgressIndicator(
                progress = { p }, color = Accent,
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(4.dp),
            )
        }
    }
}

@Composable
fun Playback(eps: List<Ep>, start: Int, prefs: SharedPreferences, onExit: () -> Unit) {
    if (eps.isEmpty()) { onExit(); return }
    val ctx = LocalContext.current
    var idx by remember { mutableIntStateOf(start.coerceIn(eps.indices)) }
    var showEpisodes by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(true) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var seeking by remember { mutableStateOf(false) }
    var seekable by remember { mutableStateOf(true) }
    val player = remember {
        ExoPlayer.Builder(ctx).setSeekBackIncrementMs(10_000).setSeekForwardIncrementMs(10_000).build()
    }

    fun save(done: Boolean = false) {
        val d = player.duration
        if (d > 0) prefs.edit()
            .putLong("p_${eps[idx].uri}", if (done) d else player.currentPosition)
            .putLong("d_${eps[idx].uri}", d).apply()
    }
    LaunchedEffect(idx) {
        val e = eps[idx]
        val p = prefs.pos(e); val d = prefs.dur(e)
        player.setMediaItem(MediaItem.fromUri(e.uri))
        player.prepare()
        player.seekTo(if (d > 0 && p > d * 0.95) 0L else p)
        player.playWhenReady = true
        playing = true
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(250)
            val d = player.duration
            duration = if (d > 0) d else 0L
            if (!seeking) position = player.currentPosition
            playing = player.isPlaying
            seekable = player.isCurrentMediaItemSeekable
            if (player.isPlaying) save()
        }
    }

    fun seekToMs(target: Long) {
        val d = player.duration
        val t = if (d > 0) target.coerceIn(0L, d) else target.coerceAtLeast(0L)
        player.seekTo(t)
        position = t
    }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        var wasPlaying = true
        val obs = LifecycleEventObserver { _, ev ->
            when (ev) {
                Lifecycle.Event.ON_PAUSE -> { wasPlaying = player.playWhenReady; save(); player.pause() }
                Lifecycle.Event.ON_RESUME -> if (wasPlaying) player.play()
                else -> {}
            }
        }
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) {
                    save(done = true)
                    if (idx + 1 < eps.size) idx++ else onExit()
                }
            }
        }
        owner.lifecycle.addObserver(obs)
        player.addListener(listener)
        onDispose {
            save(); owner.lifecycle.removeObserver(obs)
            player.removeListener(listener); player.release()
        }
    }

    fun goToEpisode(i: Int) {
        if (i in eps.indices) { save(); idx = i; showEpisodes = false }
    }
    fun formatTime(ms: Long): String {
        if (ms <= 0) return "00:00"
        val total = ms / 1000
        return "%02d:%02d".format(total / 3600, (total / 60) % 60).let {
            if (total >= 3600) it else "%02d:%02d".format(total / 60, total % 60)
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { PlayerView(it).apply {
                this.player = player
                useController = false
                keepScreenOn = true
                resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
            } },
            update = { it.player = player }
        )

        // Barre supérieure : titre de l'épisode et retour bibliothèque.
        Row(
            Modifier.align(Alignment.TopCenter).fillMaxWidth()
                .background(Panel).padding(horizontal = 18.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("MA SÉRIE  •  ÉPISODE ${idx + 1}/${eps.size}  •  recherche: ${if (seekable) "OK" else "NON"}  durée: ${duration / 1000}s", color = Color(0xFFFF5252),
                    fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(eps[idx].name, color = Color.White, fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            TextButton(onClick = onExit) { Text("Fermer", color = Color.White) }
        }

        // Contrôles principaux, toujours accessibles sur l'écran de lecture.
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .background(Panel).padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Slider(
                value = if (duration > 0) position.toFloat().coerceIn(0f, duration.toFloat()) else 0f,
                onValueChange = { seeking = true; position = it.toLong() },
                onValueChangeFinished = { seekToMs(position); seeking = false },
                valueRange = 0f..(duration.coerceAtLeast(1L).toFloat()),
                colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent)
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime(position), color = Color.LightGray, fontSize = 11.sp)
                Text(formatTime(duration), color = Color.LightGray, fontSize = 11.sp)
            }
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = { seekToMs(player.currentPosition - 10_000) }) {
                    Text("↶ 10 s", color = Color.White, fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = { if (player.isPlaying) player.pause() else player.play(); playing = player.isPlaying },
                    colors = ButtonDefaults.buttonColors(containerColor = Accent),
                    shape = RoundedCornerShape(50), modifier = Modifier.sizeIn(minWidth = 58.dp)
                ) { Text(if (playing) "Ⅱ" else "▶", fontSize = 20.sp, color = Color.White) }
                TextButton(onClick = { seekToMs(player.currentPosition + 10_000) }) { Text("10 s ↷", color = Color.White, fontWeight = FontWeight.Bold) }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = { showEpisodes = !showEpisodes }) {
                    Text(if (showEpisodes) "Masquer les épisodes" else "Épisodes disponibles", color = Color.White)
                }
                TextButton(onClick = { if (idx + 1 < eps.size) goToEpisode(idx + 1) }) {
                    Text("Prochain épisode  ›", color = if (idx + 1 < eps.size) Color.White else Color.Gray,
                        fontWeight = FontWeight.Bold)
                }
            }
        }

        if (showEpisodes) {
            Card(
                Modifier.align(Alignment.CenterEnd).fillMaxHeight(0.72f).widthIn(min = 220.dp, max = 320.dp)
                    .padding(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xF21B1B22)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(Modifier.fillMaxSize().padding(12.dp)) {
                    Text("Épisodes disponibles", color = Color.White, fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(eps.size) { i ->
                            Row(
                                Modifier.fillMaxWidth()
                                    .background(if (i == idx) Color(0xFF492126) else Color.Transparent, RoundedCornerShape(8.dp))
                                    .clickable { goToEpisode(i) }.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("${i + 1}.", color = if (i == idx) Color(0xFFFF646B) else Color.Gray)
                                Spacer(Modifier.width(8.dp))
                                Text(eps[i].name, color = Color.White, maxLines = 2,
                                    overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f), fontSize = 13.sp)
                                if (i == idx) Text("▶", color = Accent)
                            }
                        }
                    }
                }
            }
        }
    }
}
