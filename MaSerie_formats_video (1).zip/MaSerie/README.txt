Ma Série — version améliorée

1. Ouvre le dossier MaSerie dans Android Studio (File > Open), attends la synchronisation Gradle.
2. Branche ton téléphone (débogage USB activé) et clique Run, ou Build > Build APK(s).
3. Au premier lancement, choisis le dossier contenant tes vidéos (sous-dossiers acceptés).

Formats vidéo reconnus :
MP4, M4V, MKV, WEBM, AVI, MOV, 3GP, TS, M2TS, MPG, MPEG, OGV et FLV.
La lecture effective dépend des codecs pris en charge par Android/Media3 et de l'appareil.

Lecture :
- Retour de 10 secondes et avance de 10 secondes.
- Lecture/pause et barre de progression.
- Bouton « Prochain épisode ».
- Liste « Épisodes disponibles » directement pendant la lecture.
- Reprise automatique de la lecture et mémorisation de la progression.

Classement :
Les noms sont triés naturellement par numéro : Episode 2 avant Episode 10.
Pour un classement optimal, nomme les fichiers avec le titre puis le numéro, par exemple :
MaSerie - Episode 1.mp4
MaSerie - Episode 2.mkv
MaSerie - Episode 10.webm
